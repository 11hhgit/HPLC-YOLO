# -*- coding: utf-8 -*-
"""
Infrared small-target modules.

MSLCE: Multi-Scale Local Contrast Enhancement
MDEB:  Multi-scale Detail Extraction Block
LCEM:  Local Contrast Enhancement Module
"""

import torch
import torch.nn as nn
import torch.nn.functional as F


class MSLCE(nn.Module):
    """
    Multi-Scale Local Contrast Enhancement.

    保留原有MSLCE，供历史消融实验使用。
    """

    def __init__(self, c1, c2, alpha_init=0.1):
        super().__init__()

        self.kernels = (3, 5, 7)
        self.eps = 1e-6

        if c1 == c2:
            self.proj = nn.Identity()
        else:
            self.proj = nn.Sequential(
                nn.Conv2d(
                    c1,
                    c2,
                    kernel_size=1,
                    stride=1,
                    padding=0,
                    bias=False
                ),
                nn.BatchNorm2d(c2),
                nn.SiLU()
            )

        self.scale_fuse = nn.Conv2d(
            in_channels=len(self.kernels),
            out_channels=1,
            kernel_size=1,
            stride=1,
            padding=0,
            bias=True
        )

        self.refine = nn.Sequential(
            nn.Conv2d(
                c2,
                c2,
                kernel_size=3,
                stride=1,
                padding=1,
                groups=c2,
                bias=False
            ),
            nn.BatchNorm2d(c2),
            nn.SiLU(),

            nn.Conv2d(
                c2,
                c2,
                kernel_size=1,
                stride=1,
                padding=0,
                bias=False
            ),
            nn.BatchNorm2d(c2)
        )

        self.alpha = nn.Parameter(
            torch.tensor(
                float(alpha_init),
                dtype=torch.float32
            )
        )

    def forward(self, x):
        base = self.proj(x)

        spatial = base.mean(
            dim=1,
            keepdim=True
        )

        contrast_maps = []

        for kernel in self.kernels:
            local_mean = F.avg_pool2d(
                spatial,
                kernel_size=kernel,
                stride=1,
                padding=kernel // 2
            )

            contrast = torch.abs(
                spatial - local_mean
            )

            contrast_mean = contrast.mean(
                dim=(2, 3),
                keepdim=True
            )

            contrast = contrast / (
                contrast_mean + self.eps
            )

            contrast_maps.append(contrast)

        multi_scale_contrast = torch.cat(
            contrast_maps,
            dim=1
        )

        attention = torch.sigmoid(
            self.scale_fuse(
                multi_scale_contrast
            )
        )

        detail = self.refine(base)

        output = (
            base
            + torch.tanh(self.alpha)
            * attention
            * detail
        )

        return output


class MDEB(nn.Module):
    """
    Multi-scale Detail Extraction Block.

    使用3×3、5×5以及等效7×7感受野的轻量深度卷积分支，
    提取不同尺度的红外小目标局部细节。

    Input:
        [B, c1, H, W]

    Output:
        [B, c2, H, W]
    """

    def __init__(
        self,
        c1,
        c2,
        expansion=0.5,
        alpha_init=0.1
    ):
        super().__init__()

        hidden = max(
            8,
            int(c2 * expansion)
        )

        # 先压缩通道，控制参数量
        self.pre = nn.Sequential(
            nn.Conv2d(
                c1,
                hidden,
                kernel_size=1,
                stride=1,
                padding=0,
                bias=False
            ),
            nn.BatchNorm2d(hidden),
            nn.SiLU()
        )

        # 3×3局部细节分支
        self.branch3 = nn.Sequential(
            nn.Conv2d(
                hidden,
                hidden,
                kernel_size=3,
                stride=1,
                padding=1,
                groups=hidden,
                bias=False
            ),
            nn.BatchNorm2d(hidden),
            nn.SiLU()
        )

        # 5×5中尺度细节分支
        self.branch5 = nn.Sequential(
            nn.Conv2d(
                hidden,
                hidden,
                kernel_size=5,
                stride=1,
                padding=2,
                groups=hidden,
                bias=False
            ),
            nn.BatchNorm2d(hidden),
            nn.SiLU()
        )

        # 膨胀3×3，等效7×7感受野
        self.branch7 = nn.Sequential(
            nn.Conv2d(
                hidden,
                hidden,
                kernel_size=3,
                stride=1,
                padding=3,
                dilation=3,
                groups=hidden,
                bias=False
            ),
            nn.BatchNorm2d(hidden),
            nn.SiLU()
        )

        # 融合三个尺度
        self.fuse = nn.Sequential(
            nn.Conv2d(
                hidden * 3,
                c2,
                kernel_size=1,
                stride=1,
                padding=0,
                bias=False
            ),
            nn.BatchNorm2d(c2)
        )

        if c1 == c2:
            self.shortcut = nn.Identity()
        else:
            self.shortcut = nn.Sequential(
                nn.Conv2d(
                    c1,
                    c2,
                    kernel_size=1,
                    stride=1,
                    padding=0,
                    bias=False
                ),
                nn.BatchNorm2d(c2)
            )

        # 限制新分支对原始特征的扰动
        self.alpha = nn.Parameter(
            torch.tensor(
                float(alpha_init),
                dtype=torch.float32
            )
        )

        self.act = nn.SiLU()

    def forward(self, x):
        z = self.pre(x)

        detail3 = self.branch3(z)
        detail5 = self.branch5(z)
        detail7 = self.branch7(z)

        detail = self.fuse(
            torch.cat(
                (detail3, detail5, detail7),
                dim=1
            )
        )

        output = self.shortcut(x) + (
            torch.tanh(self.alpha)
            * detail
        )

        return self.act(output)


class LCEM(nn.Module):
    """
    Local Contrast Enhancement Module.

    利用3×3和7×7局部背景估计生成有符号空间门控，
    既可增强局部显著目标，也可抑制背景响应。

    Input:
        [B, c1, H, W]

    Output:
        [B, c2, H, W]
    """

    def __init__(
        self,
        c1,
        c2,
        beta_init=0.1
    ):
        super().__init__()

        if c1 == c2:
            self.proj = nn.Identity()
        else:
            self.proj = nn.Sequential(
                nn.Conv2d(
                    c1,
                    c2,
                    kernel_size=1,
                    stride=1,
                    padding=0,
                    bias=False
                ),
                nn.BatchNorm2d(c2),
                nn.SiLU()
            )

        # 输入为两个尺度的局部对比图
        self.gate = nn.Conv2d(
            in_channels=2,
            out_channels=1,
            kernel_size=3,
            stride=1,
            padding=1,
            bias=True
        )

        # 初始化时保持恒等映射，避免训练初期破坏预训练特征
        nn.init.zeros_(self.gate.weight)
        nn.init.zeros_(self.gate.bias)

        self.beta = nn.Parameter(
            torch.tensor(
                float(beta_init),
                dtype=torch.float32
            )
        )

    def forward(self, x):
        base = self.proj(x)

        # 通道压缩为空间响应图
        spatial = base.mean(
            dim=1,
            keepdim=True
        )

        # 两种尺度的局部背景估计
        local3 = F.avg_pool2d(
            spatial,
            kernel_size=3,
            stride=1,
            padding=1
        )

        local7 = F.avg_pool2d(
            spatial,
            kernel_size=7,
            stride=1,
            padding=3
        )

        # 局部目标—背景对比
        contrast3 = torch.abs(
            spatial - local3
        )

        contrast7 = torch.abs(
            spatial - local7
        )

        contrast = torch.cat(
            (contrast3, contrast7),
            dim=1
        )

        # 将Sigmoid转换到[-1, 1]
        # 正值增强目标，负值抑制背景
        gate = (
            2.0
            * torch.sigmoid(
                self.gate(contrast)
            )
            - 1.0
        )

        output = base * (
            1.0
            + torch.tanh(self.beta)
            * gate
        )

        return output

class CSAF(nn.Module):
        """
        Contrast-Semantic Adaptive Fusion module.

        用途：
        用在 P2 下采样特征 与 P3 语义特征 concat 之后。

        输入：
            x: [B, C1, H, W]
            默认 x 由两部分组成：
                前半部分或较少通道部分：来自 P2 的细节特征
                后半部分或较多通道部分：来自 P3 的语义特征

        输出：
            y: [B, C2, H, W]

        设计思想：
            1. 将 P2 细节特征和 P3 语义特征分别投影到同一通道数；
            2. 根据局部对比先验生成两个空间权重；
            3. 在疑似小目标区域增强 P2 细节；
            4. 在背景区域更多依赖 P3 语义；
            5. 最后进行轻量卷积细化。
        """

        def __init__(self, c1, c2):
            super().__init__()

            self.c1 = c1
            self.c2 = c2

            # 你的当前结构中：
            # Concat = 32通道P2下采样特征 + 64通道P3特征 = 96通道
            # 输出 c2 = 64
            #
            # 所以这里默认：
            # 语义分支通道数 = c2
            # 细节分支通道数 = c1 - c2
            if c1 > c2:
                self.detail_c = c1 - c2
                self.semantic_c = c2
            else:
                # 兜底写法，防止以后换结构时报错
                self.detail_c = c1 // 2
                self.semantic_c = c1 - self.detail_c

            # P2细节分支投影到c2通道
            self.detail_proj = nn.Sequential(
                nn.Conv2d(self.detail_c, c2, kernel_size=1, stride=1, padding=0, bias=False),
                nn.BatchNorm2d(c2),
                nn.SiLU()
            )

            # P3语义分支投影到c2通道
            self.semantic_proj = nn.Sequential(
                nn.Conv2d(self.semantic_c, c2, kernel_size=1, stride=1, padding=0, bias=False),
                nn.BatchNorm2d(c2),
                nn.SiLU()
            )

            # 根据局部对比先验 + 细节特征 + 语义特征生成两个权重
            # 输出2个通道：
            #   weight[:,0] 对应 P2细节权重
            #   weight[:,1] 对应 P3语义权重
            self.weight_gen = nn.Sequential(
                nn.Conv2d(c2 * 2 + 1, c2 // 2, kernel_size=3, stride=1, padding=1, bias=False),
                nn.BatchNorm2d(c2 // 2),
                nn.SiLU(),
                nn.Conv2d(c2 // 2, 2, kernel_size=1, stride=1, padding=0, bias=True)
            )

            # 融合后的轻量细化
            self.refine = nn.Sequential(
                nn.Conv2d(c2, c2, kernel_size=3, stride=1, padding=1, groups=c2, bias=False),
                nn.BatchNorm2d(c2),
                nn.SiLU(),

                nn.Conv2d(c2, c2, kernel_size=1, stride=1, padding=0, bias=False),
                nn.BatchNorm2d(c2),
                nn.SiLU()
            )

            # 残差强度，初始较小，避免训练初期破坏特征
            self.gamma = nn.Parameter(
                torch.tensor(0.1, dtype=torch.float32)
            )

        def forward(self, x):
            # 按通道拆分
            detail = x[:, :self.detail_c, :, :]
            semantic = x[:, self.detail_c:, :, :]

            detail = self.detail_proj(detail)
            semantic = self.semantic_proj(semantic)

            # 局部对比先验：来自细节分支
            # 用平均响应与局部均值的差异表示局部显著性
            spatial = detail.mean(dim=1, keepdim=True)

            local_mean = F.avg_pool2d(
                spatial,
                kernel_size=5,
                stride=1,
                padding=2
            )

            contrast = torch.abs(spatial - local_mean)

            # 简单归一化，防止不同图片数值范围差异过大
            contrast = contrast / (
                    contrast.mean(dim=(2, 3), keepdim=True) + 1e-6
            )

            # 生成两个融合权重
            weight_input = torch.cat(
                [contrast, detail, semantic],
                dim=1
            )

            weights = self.weight_gen(weight_input)

            # 在 detail 和 semantic 两个分支之间做softmax
            weights = torch.softmax(weights, dim=1)

            wd = weights[:, 0:1, :, :]
            ws = weights[:, 1:2, :, :]

            fused = wd * detail + ws * semantic

            out = fused + torch.tanh(self.gamma) * self.refine(fused)

            return out